﻿// 88 Заменить все вхождения подстроки w в строке st на строку v. 
//Вывести на экран первоначальную строку и конечную строку

String s = Console.ReadLine();
System.Console.WriteLine($"Первоначальная строчка {s}");
System.Console.WriteLine($"Измененная строчка {s.Replace('a', 'b')}");
