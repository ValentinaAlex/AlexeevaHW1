﻿// 85. Преобразовать во вводимой с клавиатуры строке строчные латинские буквы в прописные

string s=Console.ReadLine();
System.Console.WriteLine(s.ToLower());