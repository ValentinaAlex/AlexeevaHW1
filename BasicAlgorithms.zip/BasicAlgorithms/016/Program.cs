﻿// 16 Дано число. Проверить кратно ли оно 7 и 23
int n=Convert.ToInt32(Console.ReadLine());
if (n%7==0 && n%23==0) System.Console.WriteLine("yes"); else System.Console.WriteLine("no");

